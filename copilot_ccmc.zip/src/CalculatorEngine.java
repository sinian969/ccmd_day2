import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class CalculatorEngine {
    public static double calculate(String expression) {
        String input = expression.replace(" ", "");
        if (input.isEmpty()) {
            return 0;
        }

        List<String> tokens = tokenize(input);
        return evaluateTokens(tokens);
    }

    private static List<String> tokenize(String input) {
        List<String> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (Character.isDigit(ch) || ch == '.') {
                current.append(ch);
            } else {
                if (current.length() > 0) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
                tokens.add(String.valueOf(ch));
            }
        }

        if (current.length() > 0) {
            tokens.add(current.toString());
        }

        return normalizeUnaryMinus(tokens);
    }

    private static List<String> normalizeUnaryMinus(List<String> tokens) {
        List<String> normalized = new ArrayList<>();
        boolean expectOperand = true;

        for (String token : tokens) {
            if ("+".equals(token) || "-".equals(token) || "*".equals(token) || "/".equals(token) || "(".equals(token)) {
                if ("-".equals(token) && expectOperand) {
                    normalized.add("u-");
                } else {
                    normalized.add(token);
                }
                expectOperand = true;
                if ("(".equals(token)) {
                    expectOperand = true;
                }
            } else if (")".equals(token)) {
                normalized.add(token);
                expectOperand = false;
            } else {
                normalized.add(token);
                expectOperand = false;
            }
        }
        return normalized;
    }

    private static double evaluateTokens(List<String> tokens) {
        Stack<Double> values = new Stack<>();
        Stack<String> operators = new Stack<>();

        for (String token : tokens) {
            if (isNumber(token)) {
                values.push(Double.parseDouble(token));
            } else if ("(".equals(token)) {
                operators.push(token);
            } else if (")".equals(token)) {
                while (!operators.isEmpty() && !"(".equals(operators.peek())) {
                    applyOperator(values, operators.pop());
                }
                if (!operators.isEmpty()) {
                    operators.pop();
                }
            } else if (isOperator(token)) {
                while (!operators.isEmpty() && hasPrecedence(operators.peek(), token)) {
                    applyOperator(values, operators.pop());
                }
                operators.push(token);
            }
        }

        while (!operators.isEmpty()) {
            applyOperator(values, operators.pop());
        }

        if (values.isEmpty()) {
            return 0;
        }
        return values.pop();
    }

    private static boolean isNumber(String token) {
        try {
            Double.parseDouble(token);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private static boolean isOperator(String token) {
        return "+".equals(token) || "-".equals(token) || "*".equals(token) || "/".equals(token) || "u-".equals(token);
    }

    private static int precedence(String operator) {
        if ("*".equals(operator) || "/".equals(operator)) {
            return 2;
        }
        if ("+".equals(operator) || "-".equals(operator) || "u-".equals(operator)) {
            return 1;
        }
        return 0;
    }

    private static boolean hasPrecedence(String top, String current) {
        return !"(".equals(top) && precedence(top) >= precedence(current);
    }

    private static void applyOperator(Stack<Double> values, String operator) {
        if ("u-".equals(operator)) {
            if (!values.isEmpty()) {
                values.push(-values.pop());
            }
            return;
        }

        if (values.size() < 2) {
            return;
        }

        double right = values.pop();
        double left = values.pop();

        switch (operator) {
            case "+":
                values.push(left + right);
                break;
            case "-":
                values.push(left - right);
                break;
            case "*":
                values.push(left * right);
                break;
            case "/":
                if (right == 0) {
                    throw new ArithmeticException("0으로 나눌 수 없습니다.");
                }
                values.push(left / right);
                break;
            default:
                break;
        }
    }
}
