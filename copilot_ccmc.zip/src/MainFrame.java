import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cards = new JPanel(cardLayout);
    private final List<Member> members = new ArrayList<>();
    private final StringBuilder expression = new StringBuilder();
    private final DefaultListModel<String> memberListModel = new DefaultListModel<>();
    private final JList<String> memberList = new JList<>(memberListModel);
    private boolean justCalculated = false;

    public MainFrame() {
        setTitle("Swing 메뉴 앱");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("메뉴");

        JMenuItem calculatorItem = new JMenuItem("계산기");
        JMenuItem signupItem = new JMenuItem("회원가입");
        JMenuItem listItem = new JMenuItem("회원리스트");

        calculatorItem.addActionListener(e -> cardLayout.show(cards, "calculator"));
        signupItem.addActionListener(e -> cardLayout.show(cards, "signup"));
        listItem.addActionListener(e -> {
            refreshMemberList();
            cardLayout.show(cards, "memberList");
        });

        menu.add(calculatorItem);
        menu.add(signupItem);
        menu.add(listItem);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        JPanel calculatorPanel = buildCalculatorPanel();
        JPanel signupPanel = buildSignupPanel();
        JPanel memberListPanel = buildMemberListPanel();

        cards.add(calculatorPanel, "calculator");
        cards.add(signupPanel, "signup");
        cards.add(memberListPanel, "memberList");

        add(cards, BorderLayout.CENTER);
        cardLayout.show(cards, "calculator");
    }

    private JPanel buildCalculatorPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextField display = new JTextField("0");
        display.setFont(new Font("Malgun Gothic", Font.BOLD, 28));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        panel.add(display, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(5, 4, 8, 8));
        String[] buttons = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "0", ".", "C", "+",
                "=", "(", ")", ""
        };

        for (String text : buttons) {
            if (text.isEmpty()) {
                buttonPanel.add(new JPanel());
                continue;
            }
            JButton button = new JButton(text);
            button.setFont(new Font("Malgun Gothic", Font.BOLD, 18));
            button.addActionListener(e -> handleCalculatorButton(text, display));
            buttonPanel.add(button);
        }

        panel.add(buttonPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildSignupPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("회원가입");
        title.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        panel.add(title, c);

        c.gridwidth = 1;
        c.gridy = 1;
        panel.add(new JLabel("이름"), c);
        JTextField nameField = new JTextField();
        c.gridx = 1;
        panel.add(nameField, c);

        c.gridx = 0;
        c.gridy = 2;
        panel.add(new JLabel("이메일"), c);
        JTextField emailField = new JTextField();
        c.gridx = 1;
        panel.add(emailField, c);

        c.gridx = 0;
        c.gridy = 3;
        panel.add(new JLabel("전화번호"), c);
        JTextField phoneField = new JTextField();
        c.gridx = 1;
        panel.add(phoneField, c);

        JButton saveButton = new JButton("등록");
        c.gridx = 0;
        c.gridy = 4;
        c.gridwidth = 2;
        panel.add(saveButton, c);

        JLabel messageLabel = new JLabel(" ");
        c.gridy = 5;
        panel.add(messageLabel, c);

        saveButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                messageLabel.setText("모든 항목을 입력해주세요.");
                return;
            }

            members.add(new Member(name, email, phone));
            nameField.setText("");
            emailField.setText("");
            phoneField.setText("");
            messageLabel.setText("회원 등록이 완료되었습니다.");
        });

        return panel;
    }

    private JPanel buildMemberListPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("회원리스트");
        title.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        panel.add(title, BorderLayout.NORTH);

        memberList.setFont(new Font("Malgun Gothic", Font.PLAIN, 16));
        panel.add(new JScrollPane(memberList), BorderLayout.CENTER);

        JButton refreshButton = new JButton("새로고침");
        refreshButton.addActionListener(e -> refreshMemberList());
        panel.add(refreshButton, BorderLayout.SOUTH);

        return panel;
    }

    private void handleCalculatorButton(String text, JTextField display) {
        switch (text) {
            case "C":
                expression.setLength(0);
                display.setText("0");
                justCalculated = false;
                break;
            case "=":
                if (expression.length() == 0) {
                    return;
                }
                try {
                    double result = CalculatorEngine.calculate(expression.toString());
                    display.setText(String.valueOf(result));
                    expression.setLength(0);
                    expression.append(result);
                    justCalculated = true;
                } catch (Exception ex) {
                    display.setText("오류");
                    expression.setLength(0);
                    justCalculated = false;
                }
                break;
            default:
                if (justCalculated && !"+".equals(text) && !"-".equals(text) && !"*".equals(text) && !"/".equals(text)) {
                    expression.setLength(0);
                    justCalculated = false;
                }
                if (expression.length() == 0 && "0".equals(display.getText())) {
                    expression.setLength(0);
                }
                expression.append(text);
                display.setText(expression.toString());
                break;
        }
    }

    private void refreshMemberList() {
        memberListModel.clear();
        if (members.isEmpty()) {
            memberListModel.addElement("등록된 회원이 없습니다.");
            return;
        }
        for (Member member : members) {
            memberListModel.addElement(member.toString());
        }
    }
}
