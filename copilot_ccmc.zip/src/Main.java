import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        if (args.length > 0 && "--self-test".equals(args[0])) {
            runSelfTest();
            return;
        }

        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }

    private static void runSelfTest() {
        double result1 = CalculatorEngine.calculate("3+4*2");
        double result2 = CalculatorEngine.calculate("10/2+3");
        double result3 = CalculatorEngine.calculate("(2+3)*4");

        if (Math.abs(result1 - 11.0) < 0.0001
                && Math.abs(result2 - 8.0) < 0.0001
                && Math.abs(result3 - 20.0) < 0.0001) {
            System.out.println("Self-test passed.");
        } else {
            throw new IllegalStateException("Self-test failed.");
        }
    }
}
