# Java Swing 메뉴 앱

이 프로젝트는 Java Swing으로 만든 예제 앱입니다.

## 포함 기능
- 계산기 화면
- 회원가입 화면
- 회원리스트 화면

## 실행 방법
```bash
javac -d out src/*.java
java -cp out Main
```

## 자체 검증
```bash
java -cp out Main --self-test
```
